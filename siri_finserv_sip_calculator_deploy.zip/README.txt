SIRI FINSERV FINANCIAL SERVICES — SIP CALCULATOR

Files:
- index.html: complete standalone calculator. No API key, backend, database, or external library required.

Test locally:
- Open index.html in a modern browser.

Deploy to Netlify:
1. Sign in at https://app.netlify.com/
2. Choose Add new site / Deploy manually (wording may vary).
3. Drag and drop the folder containing index.html, or upload the ZIP.
4. Netlify will publish the site and provide a public URL ending in netlify.app.
5. You can rename the site in Netlify site settings.

Calculation:
- Monthly nominal rate = annual assumed rate / 12 / 100.
- Number of instalments = years * 12.
- End-of-month SIP FV = P * (((1+r)^n - 1) / r).
- Beginning-of-month SIP FV = end-of-month FV * (1+r).
- At 0% assumed return, FV = total contributions.

Important:
This is an illustrative calculator, not investment advice or a return guarantee.
Review the disclaimer and applicable regulatory requirements before sharing with clients.
